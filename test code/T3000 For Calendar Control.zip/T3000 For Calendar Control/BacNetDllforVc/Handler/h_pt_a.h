#pragma once
#ifndef __H_PT_A_HH
#define  __H_PT_A_HH

 void ProcessPTA(BACNET_PRIVATE_TRANSFER_DATA * data);


#endif