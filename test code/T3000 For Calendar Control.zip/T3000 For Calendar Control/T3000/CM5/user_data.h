#ifndef USER_DATA_H
#define USER_DATA_H

#include "ud_str.h"

//extern uint8_t  Input[380];
//extern uint8_t  Output[400];
//extern Str_out_point  	*ptrOutputs;
//extern uint8_t								 no_outs;
//extern Str_in_point   	*ptrInputs;
//extern uint8_t								 no_ins;



#endif



