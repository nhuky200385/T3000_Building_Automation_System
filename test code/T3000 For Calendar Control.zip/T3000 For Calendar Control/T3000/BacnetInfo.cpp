//BacnetInfo.cpp : implementation file*/


#include "stdafx.h"
#include "T3000.h"
#include "BacnetInfo.h"
#include "afxdialogex.h"


// CBacnetInfo dialog
//
//	 IMPLEMENT_DYNAMIC(CBacnetInfo, CDialogEx)
//
//CBacnetInfo::CBacnetInfo(CWnd* pParent /*=NULL*/)
//	: CDialogEx(CBacnetInfo::IDD, pParent)
//{
//
//}
//
//CBacnetInfo::~CBacnetInfo()
//{
//}
//
//void CBacnetInfo::DoDataExchange(CDataExchange* pDX)
//{
//	CDialogEx::DoDataExchange(pDX);
//}
//
//
//BEGIN_MESSAGE_MAP(CBacnetInfo, CDialogEx)
//END_MESSAGE_MAP()
//
//
// CBacnetInfo message handlers
