#pragma once


// CBacnetInfo dialog

//class CBacnetInfo : public CDialogEx
//{
//	DECLARE_DYNAMIC(CBacnetInfo)
//
//public:
//	CBacnetInfo(CWnd* pParent = NULL);   // standard constructor
//	virtual ~CBacnetInfo();
//
//// Dialog Data
//	enum { IDD = IDD_DIALOG_BACNET_INFO };
//
//protected:
//	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
//
//	DECLARE_MESSAGE_MAP()
//};
