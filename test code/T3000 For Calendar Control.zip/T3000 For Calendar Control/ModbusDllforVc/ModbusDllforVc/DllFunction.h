#pragma  once
#include "define.h"
OUTPUT HANDLE Open_Testo_USB();
OUTPUT int ReadTestoDeviceData(float reveivevalue[]);